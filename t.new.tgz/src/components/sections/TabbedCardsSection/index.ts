export { default } from "./TabbedCardsSection";
